function compilePeople(){
	var people = {};
	var mydata = data.setting;
	var div = document.getElementById('data');
	for(var i = 0;i < mydata.length; i++){
		for(var j = 0;j < mydata[i].nations.length; j++){
			for(var k = 0;k < mydata[i].nations[j].people.length; k++)
			{	
				var person = mydata[i].nations[j].people[k];
				people[person.id] = 
					{
						"name" : person.name,
						"status" : person.status,
						"desc" : person.desc,
						"id" : person.id,
						"locationid": person.locationid,
						"job" : person.job,
						"associates":person.associates
					};
			};
		};
	};
    return people 
};

function compileNations(){
	var nations = {};
	var mydata = data.setting;
	var div = document.getElementById('data');
	for(var i = 0;i < mydata.length; i++){
		for(var j = 0;j< mydata[i].nations.length; j++){
			var nation = mydata[i].nations[j];
			nations[nation.id] = 
				{
					"name" : nation.name,
					"id":nation.id,
					"capitalid"	: nation.capitalid,
					"desc": nation.desc,
					"allies":nation.allies,
					"enemies":nation.enemies
				}
		};			
	};
	return nations;
};

function compilePOIs()	{
	var pois = {};
	var mydata = data.setting;
	var div = document.getElementById('data');
	for(var i = 0;i < mydata.length; i++){
		for(var j = 0;j < mydata[i].nations.length; j++){
			for(var k = 0;k < mydata[i].nations[j].places.length; k++){
				for(var l=0;l< mydata[i].nations[j].places[k].poi.length; l++){
					var poi = mydata[i].nations[j].places[k].poi[l];
					pois[poi.id] = {
						"name":poi.name,
						"id":poi.id,
						"locationid":poi.locationid,
						"desc":poi.desc
					};
				};
			};
		};		
	};
	return pois
	
};

function compileTowns(){
	var towns = {};
	var mydata = data.setting;			 
	var div = document.getElementById('data');
	for(var i = 0;i < mydata.length; i++){
		for(var j = 0;j < mydata[i].nations.length; j++){
			for(var k = 0;k < mydata[i].nations[j].places.length; k++){	
				var town = mydata[i].nations[j].places[k];
				towns[town.id]=
					{
						"id":town.id,
						"name":town.name,
						"desc":town.desc,
						"pop":town.pop,
						"category":town.category,
						"poi" : [
							{"id":"D_1"},
							{"id":"D_2"}
						],
						"importantpeople":[
							{"id":"D_1"},
							{"id":"D_2",}
						]
					}
			};
		};		
	};
	return towns;
};

function changeNations(culture){
	var mydata = data.setting;
	if (culture.length == 0) {
		document.getElementById("townDropdown").innerHTML = "<option></option>";
	}
	else {
		var nationOptions = "";
		nationOptions += "<option value='' disabled selected>Select</option>"	
		for(var i = 0;i < mydata.length; i++){
			if(mydata[i].culture == culture){
				for(var j = 0; j<mydata[i].nations.length;j++){
					nationOptions += "<option value='" + mydata[i].nations[j].id +"'>" + mydata[i].nations[j].name + "</option>";
				}
			}
		}
		document.getElementById("nationDropdown").innerHTML = nationOptions;
	}
}

function changeTowns(nation){
	var mydata = data.setting;
	if (nation.length == 0) {
		document.getElementById("townDropdown").innerHTML = "<option></option>";
	}
	else {
		var townOptions = "";
		townOptions += "<option value='' disabled selected>Select</option>"	
		for(var i = 0;i < mydata.length; i++){
			for(var j = 0; j<mydata[i].nations.length;j++){
			console.log(nation)
				if(mydata[i].nations[j].id == nation){
					for(var k =0; k<mydata[i].nations[j].places.length;k++){
						townOptions += "<option value='" + mydata[i].nations[j].places[k].id +"'>" + mydata[i].nations[j].places[k].name + "</option>";
					}
				}
			}
		}
		console.log(document.getElementById("townDropdown").innerHTML);
		console.log(townOptions);
		document.getElementById("townDropdown").innerHTML = townOptions;
	}
}

