string = "";
			
string += "<nav class=\"navbar navbar-expand-sm bg-dark navbar-dark\" id=\"LogoHeader\"\">";
	string +="<div class=\"navbar-brand\">";
	string +="<a class=\"navbar-brand\" href=\"../Views/index.html\">Empire of the Inland Sea</a>";
	string +="</div>";
string +="<ul class='navbar-nav navbar-dark'>";
string +="<li class=\"nav-item\"><a class='nav-link' href=\"../Nations/NationsIndex.html\">Nations</a></li>";
string +="<li class=\"nav-item\"><a class='nav-link' href=\"../Towns/TownsIndex.html\">Towns</a></li>";
string +="<li class=\"nav-item\"><a class='nav-link' href=\"../People/PeopleIndex.html\">People</a></li>";
string +="<li class=\"nav-item\"><a class='nav-link' href=\"../POI/POIIndex.html\">POI</a></li>";
string +="<li class=\"nav-item\"><a class='nav-link' href=\"../Culture/CultureIndex.html\">Culture</a></li>";
string +="<li class=\"nav-item\"><a class='nav-link' href=\"../Gods/GodsIndex.html\">Pantheon</a></li>";

string +="</ul>";

string +="</nav>";
document.getElementById("headerTest") .innerHTML= string;