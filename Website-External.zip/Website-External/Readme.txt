Read Me
================================================================
Starts with template data saved because it will break without some data to display, this can be safely edited

Data can be viewed just by opening Index.html but you will be be able to add new data

To add data you will need to install Node.js and then run Start.bat and you will be able to save data as well