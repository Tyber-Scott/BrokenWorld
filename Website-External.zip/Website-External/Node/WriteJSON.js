fs = require('fs');
	
exports.updateCulture=function(id,name,desc){
 	fs.readFile('../data.json', 'utf8', function(err, contents) {
		var contents = contents.substr(7);
		var m = JSON.parse(contents);
		for(var i = 0;i < m.setting.length; i++){
			if(m.setting[i].culture == id){
				m.setting[i].desc = desc;
				m.setting[i].culture = name;
				var json = JSON.stringify(m);
				fs.writeFile('../data.json', "data = "+json, (err) => {
					if (err) {
						console.error(err);
						return;
					};
					console.log("File has been created");
				});
			}
		}
	});
};

exports.addCulture=function(name,desc){
 	fs.readFile('../data.json', 'utf8', function(err, contents) {
		var contents = contents.substr(7);
		var m = JSON.parse(contents); 
		//Creates a template of the JSON
		var template = {
							"name":name,
							"desc":desc,
							"nations": [],
							"gods":[]
		}
		template.culture = name;
		template.desc = desc;
		m.setting.push(template)
		var json = JSON.stringify(m);
		fs.writeFile('../data.json', "data = "+json, (err) => {
			if (err) {
				console.error(err);
				return;
			};
			console.log("File has been created");
	});
	});
};


exports.addNation=function(culture,id,name,desc){
 	fs.readFile('../data.json', 'utf8', function(err, contents) {
		var contents = contents.substr(7);
		var m = JSON.parse(contents);
		//Creates a template of the JSON

		template = {
						"id" : null,
						"name":name,
						"desc":desc,
						"capitalid":null,
						"people":[],
						"enemies":[],
						"allies":[],
						"places":[]
		}

		for(var i = 0;i < m.setting.length; i++){
			if(m.setting[i].culture == culture){
				//Finds the max ID and itterates by one
				var max_id = 0;
				for (var j = 0;j < m.setting[i].nations.length; j++){
					var id = (m.setting[i].nations[j].id).split("_")
					var prefix = id[0];
					var num = Number(id[1]);
					//Couldn't get it to increment one greater than max outside loop because im a idiot so did it in here, works fine
					//but a little funky
					if( num >= max_id){
						max_id = num +=1
					}	
				}	
				//Changes the format of the ID back into the correct one
				if (prefix == undefined) {
					prefix = culture	
				}
				template.id = prefix + "_" + max_id++;
				m.setting[i].nations.push(template);
				var json = JSON.stringify(m);
				fs.writeFile('../data.json', "data = "+json, (err) => {
					if (err) {
						console.error(err);
						return;
					};
					console.log("File has been created");
				});
			}
		}
	});
};

exports.updateNation=function(id,name,desc,capitalid,allies,enemies){
 	fs.readFile('../data.json', 'utf8', function(err, contents) {
		var contents = contents.substr(7);
		var m = JSON.parse(contents);
		alliesList = []
		//if a single element is in allies it breaks so checks for that and converts to a list
		console.log(allies)
		if((typeof allies) == 'string'){
			allies = [allies]
		}

		if((typeof enemies) == 'string'){
			enemies = [enemies]
		}
		
		//converts the list of allie ids into object so that it JSONifies nicely
		for(var allyCount = 0;allyCount < allies.length; allyCount++){
			alliesList.push({"id":allies[allyCount]});
		}
		enemiesList = []
		for(var enemeyCount = 0;enemeyCount < enemies.length; enemeyCount++){
			enemiesList.push({"id":enemies[enemeyCount]});
		}
			
		//itterates through the nations to find the right one then overrides all the data
		for(var i = 0;i < m.setting.length; i++){
			for(var j = 0;j < m.setting[i].nations.length; j++){
				if(m.setting[i].nations[j].id == id){
					m.setting[i].nations[j].name = name;
					m.setting[i].nations[j].desc = desc;
					m.setting[i].nations[j].capitalid = capitalid;
					m.setting[i].nations[j].allies = alliesList;					
					m.setting[i].nations[j].enemies = enemiesList;
					var json = JSON.stringify(m);
					fs.writeFile('../data.json', "data = "+json, (err) => {
						if (err) {
							console.error(err);
							return;
						};
						console.log("File has been created");
					});
					
				}
			}
		}
	});
};


exports.updateGod=function(id,name,alignment,domain,desc){
 	fs.readFile('../data.json', 'utf8', function(err, contents) {
		var contents = contents.substr(7);
		var m = JSON.parse(contents);
		for(var i = 0;i < m.setting.length; i++){
			for (var j = 0; j<m.setting[i].gods.length;j++){
				if(m.setting[i].gods[j].id == id){
					m.setting[i].gods[j].desc = desc;
					m.setting[i].gods[j].name = name;
					m.setting[i].gods[j].domain = domain;
					m.setting[i].gods[j].alignment = alignment;
					var json = JSON.stringify(m);
					fs.writeFile('../data.json', "data = "+json, (err) => {
						if (err) {
							console.error(err);
							return;
						};
						console.log("File has been created");
					});
				}
			}
		}
	});
};

exports.addGod=function(culture,name,desc,alignment,domain){
 	fs.readFile('../data.json', 'utf8', function(err, contents) {
		var contents = contents.substr(7);
		var m = JSON.parse(contents);
		//Creates a template of the JSON

		template = {
						"id":null,
						"name":name,
						"desc":desc,
						"alignment":alignment,
						"domain":domain,
		}

		for(var i = 0;i < m.setting.length; i++){
			//sets the God to the right culture
			if(m.setting[i].culture == culture){
				//Finds the max ID and itterates by one
				var max_id = 0;
				var prefix = culture[0];
				for (var j = 0;j < m.setting[i].gods.length; j++){
					var id = (m.setting[i].gods[j].id).split("_")
					 prefix = id[0];
					var num = Number(id[1]);
					//Couldn't get it to increment one greater than max outside loop because im a idiot so did it in here, works fine
					//but a little funky
					if( num >= max_id){
						max_id = num +=1
					}	
				}
				if (prefix == undefined) {
					prefix = culture	
				}
				//Changes the format of the ID back into the correct one
				template.id = prefix + "_" + max_id++;
				m.setting[i].gods.push(template);
				var json = JSON.stringify(m);
				fs.writeFile('../data.json', "data = "+json, (err) => {
					if (err) {
						console.error(err);
						return;
					};
					console.log("File has been created");
				});
			}
		}
	});
};


exports.addTown=function(culture,name,desc,nation,pop,cat){
 	fs.readFile('../data.json', 'utf8', function(err, contents) {
		var contents = contents.substr(7);
		var m = JSON.parse(contents);
		//Creates a template of the JSON

		template = {
						"id" : null,
						"name":name,
						"desc":desc,
						"pop":pop,
						"category":cat,
						"poi":[],
						"importantpeople":[]

		}

		for(var i = 0;i < m.setting.length; i++){
			if(m.setting[i].culture == culture){
				//Finds the max ID and itterates by one
				var max_id = 0;
				for (var j = 0;j < m.setting[i].nations.length; j++){
					for (var k =0; k<m.setting[i].nations[j].places.length;k++){
						var id = (m.setting[i].nations[j].places[k].id).split("_")
						var prefix = id[0];
						var num = Number(id[1]);
						//Couldn't get it to increment one greater than max outside loop because im a idiot so did it in here, works fine
						//but a little funky
						if( num >= max_id){
							max_id = num +=1
						}
					}	
				}
				for (var j = 0;j < m.setting[i].nations.length; j++){
					if(m.setting[i].nations[j].id == nation){
						//Changes the format of the ID back into the correct one
						if (prefix == undefined) {
							prefix = culture	
						}
						template.id = prefix + "_" + max_id++;
						m.setting[i].nations[j].places.push(template);
						var json = JSON.stringify(m);
						console.log(template)
						fs.writeFile('../data.json', "data = "+json, (err) => {
							if (err) {
								console.error(err);
								return;
							};
							console.log("File has been created");
						
						});
					}
				}
			}
		}
	});
};

exports.updateTown=function(id,name,desc,pop, category,importantpeople){
 	fs.readFile('../data.json', 'utf8', function(err, contents) {
		var contents = contents.substr(7);
		var m = JSON.parse(contents);
		//finds the correct place and overwrites the values
		for(var i = 0;i < m.setting.length; i++){
			for (var j = 0;j < m.setting[i].nations.length; j++){
				for (var k = 0; k< m.setting[i].nations[j].places.length; k++){	
					if(m.setting[i].nations[j].places[k].id == id){
						m.setting[i].nations[j].places[k].name = name;
						m.setting[i].nations[j].places[k].desc = desc;
						m.setting[i].nations[j].places[k].pop = pop;
						m.setting[i].nations[j].places[k].category = category;
						m.setting[i].nations[j].places[k].importantpeople= importantpeople;
						console.log(m.setting[i].nations[j].places[k].importantpeople);
						var json = JSON.stringify(m);
						fs.writeFile('../data.json', "data = "+json, (err) => {
							if (err) {
								console.error(err);
								return;
							};
							console.log("File has been created");
						});
					
					}
				}
			}
			
		}
	});
};


exports.addPerson=function(culture,name,desc,nation,status_,race,job,town){
 	fs.readFile('../data.json', 'utf8', function(err, contents) {
		var contents = contents.substr(7);
		var m = JSON.parse(contents);
		//Creates a template of the JSON

		template = {
						"id" : null,
						"name":name,
						"desc":desc,
						"status":status_,
						"race":race,
						"job":job,
						"locationid":town,
						"associates":[]

		}

		for(var i = 0;i < m.setting.length; i++){
			if(m.setting[i].culture == culture){
				//Finds the max ID and itterates by one
				var max_id = 0;
				for (var j = 0;j < m.setting[i].nations.length; j++){
					for (var k =0; k<m.setting[i].nations[j].people.length;k++){
						var id = (m.setting[i].nations[j].people[k].id).split("_")
						var prefix = id[0];
						var num = Number(id[1]);
						//Couldn't get it to increment one greater than max outside loop because im a idiot so did it in here, works fine
						//but a little funky
						if( num >= max_id){
							max_id = num +=1
						}
					}	
				}
				for (var j = 0;j < m.setting[i].nations.length; j++){
					if(m.setting[i].nations[j].id == nation){
						//Changes the format of the ID back into the correct one
						if (prefix == undefined) {
							prefix = culture	
						}
						template.id = prefix + "_" + max_id++;
						m.setting[i].nations[j].people.push(template);
						var json = JSON.stringify(m);
						console.log(template)
						fs.writeFile('../data.json', "data = "+json, (err) => {
							if (err) {
								console.error(err);
								return;
							};
							console.log("File has been created");
						
						});
					}
				}
			}
		}
	});
};

exports.updatePerson=function(name,status1,desc,id,race,job,locationid,associates){
 	fs.readFile('../data.json', 'utf8', function(err, contents) {
		var contents = contents.substr(7);
		var m = JSON.parse(contents);
		//finds the correct place and overwrites the values
		for(var i = 0;i < m.setting.length; i++){
			for (var j = 0;j < m.setting[i].nations.length; j++){
				for (var k = 0; k< m.setting[i].nations[j].people.length; k++){	
					if(m.setting[i].nations[j].people[k].id == id){
						m.setting[i].nations[j].people[k].name = name;
						m.setting[i].nations[j].people[k].status = status1;
						m.setting[i].nations[j].people[k].desc = desc;
						m.setting[i].nations[j].people[k].race = race;
						m.setting[i].nations[j].people[k].job = job;
						m.setting[i].nations[j].people[k].locationid = locationid;
						m.setting[i].nations[j].people[k].associates= associates;
						var json = JSON.stringify(m);
						fs.writeFile('../data.json', "data = "+json, (err) => {
							if (err) {
								console.error(err);
								return;
							};
							console.log("File has been created");
						});
					
					}
				}
			}
			
		}
	});
};


exports.addPOI=function(culture,nation,town, name, desc){
 	fs.readFile('../data.json', 'utf8', function(err, contents) {
		var contents = contents.substr(7);
		var m = JSON.parse(contents);
		//Creates a template of the JSON

		template = {
						"id" : null,
						"name":name,
						"desc":desc
		}

		for(var i = 0;i < m.setting.length; i++){
			if(m.setting[i].culture == culture){
				//Finds the max ID and itterates by one
				var max_id = 0;
				for (var j = 0;j < m.setting[i].nations.length; j++){
					for (var k =0; k<m.setting[i].nations[j].places.length;k++){
						for (var l =0; l<m.setting[i].nations[j].places[k].poi.length;l++){
							var id = (m.setting[i].nations[j].places[k].poi[l].id).split("_")
							var prefix = id[0];
							var num = Number(id[1]);
							//Couldn't get it to increment one greater than max outside loop because im a idiot so did it in here, works fine
							//but a little funky
							if( num >= max_id){
								max_id = num +=1
							}
						}
					}	
				}
				for (var j = 0;j < m.setting[i].nations.length; j++){
					if(m.setting[i].nations[j].id == nation){
						for (var k = 0;k < m.setting[i].nations[j].places.length; k++){
							if(m.setting[i].nations[j].places[k].id == town){
								//Changes the format of the ID back into the correct one
								if (prefix == undefined) {
									prefix = culture	
								}				
								template.id = prefix + "_" + max_id++;
								m.setting[i].nations[j].places[k].poi.push(template);
								var json = JSON.stringify(m);
								console.log(template)
								fs.writeFile('../data.json', "data = "+json, (err) => {
									if (err) {
										console.error(err);
										return;
									};
									console.log("File has been created");
								});
							}
						}
					}
				}
			}
		}
	});
};

exports.updatePOI=function(id,name, desc){
	fs.readFile('../data.json', 'utf8', function(err, contents) {
		var contents = contents.substr(7);
		var m = JSON.parse(contents);
		//finds the correct place and overwrites the values
		for(var i = 0;i < m.setting.length; i++){
			for (var j = 0;j < m.setting[i].nations.length; j++){
				for (var k = 0; k< m.setting[i].nations[j].places.length; k++){	
					for (var l=0; l< m.setting[i].nations[j].places[k].poi.length; l++){
						console.log(m.setting[i].nations[j].places[k].poi.length);
						console.log(m.setting[i].nations[j].places[k].poi[l]);
						if(m.setting[i].nations[j].places[k].poi[l].id == id){
							m.setting[i].nations[j].places[k].poi[l].name = name;
							m.setting[i].nations[j].places[k].poi[l].desc = desc;
							var json = JSON.stringify(m);
							fs.writeFile('../data.json', "data = "+json, (err) => {
								if (err) {
									console.error(err);
									return;
								};
								console.log("File has been created");
							});
						
						}
					}
				}
			}
			
		}
	});
};