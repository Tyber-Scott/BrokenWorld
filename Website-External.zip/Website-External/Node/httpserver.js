var http=require("http");
var routing = require('./WikiRouting');
var url = require("url");
querystring=require("querystring");

http.createServer(function(request, response) {
	
		if(request.url==="/favicon.ico"){
			   response.writeHead(200,{"Content-Type":"image/x-icon"});
			   response.end();
			   return;
		}

		else{
			data1= '';
			request.on('data', function(chunk) {               
				data1 += chunk;             
			});    
			request.on('end', function() {
				qs=querystring.parse(data1);
				//console.log(desc);
			});
				
			var url_parts = url.parse(request.url);
			routing.enableRoute(url_parts,request,response);   
		}
  }
).listen(3000);

console.log("Server started");