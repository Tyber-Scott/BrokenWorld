var routeHandler = require('./RouteHandler');
var re = /ab+c/;
exports.enableRoute=function(url,request,response){
                                       //Get the pathname from the request.url
                                       var pathname=url.pathname;
                                       //According to the path name received, invoke the corresponding function
                                       switch(pathname) {
										case '/data.json': routeHandler.get_Data(pathname, request, response);;
                                                                break;
																
										case '/functions.js': routeHandler.get_Functions(pathname, request, response);;
                                                                break;
																
										case '/header.js': routeHandler.get_Header(pathname, request, response);;
																break;
																
																
																
										case '/Gods/addGod':routeHandler.add_God(pathname, request, response);
																break;
										case '/Gods/editGod':routeHandler.update_God(pathname, request, response);
                                                                break;
										case '/Gods/GodsEdit.html':routeHandler.display_GodsEdit(pathname, request, response);
                                                                break;
										case '/Gods/GodsNew.html':routeHandler.display_GodsNew(pathname, request, response);
                                                                break;
										case '/Gods/GodsTemplate.html': routeHandler.display_GodsTemplate(pathname, request, response);
                                                                break;																									
										case '/Gods/GodsIndex.html':routeHandler.display_GodsIndex(pathname, request, response);
                                                                break;
																
										
																
																
										case '/Culture/addCulture':routeHandler.add_Culture(pathname, request, response);
                                                                break;														
										case '/Culture/editCulture':routeHandler.update_Culture(pathname, request, response);
                                                                break;
										case '/Culture/CultureEdit.html':routeHandler.display_CultureEdit(pathname, request, response);
                                                                break;
										case '/Culture/CultureNew.html':routeHandler.display_CultureNew(pathname, request, response);
                                                                break;
										case '/Culture/CultureTemplate.html': routeHandler.display_CultureTemplate(pathname, request, response);
                                                                break;																									
										case '/Culture/CultureIndex.html':routeHandler.display_CultureIndex(pathname, request, response);
                                                                break;
																
										
													
										case '/Nations/addNation':routeHandler.add_Nation(pathname, request, response);
                                                                break;	
										case '/Nations/editNation':routeHandler.update_Nation(pathname, request, response);
                                                                break;
										case '/Nations/NationsEdit.html':routeHandler.display_NationsEdit(pathname, request, response);
                                                                break;	
										case '/Nations/NationsNew.html': routeHandler.display_NationNew(pathname, request, response);
                                                                break;						
										case '/Nations/NationsTemplate.html': routeHandler.display_NationsTemplate(pathname, request, response);
                                                                break;																									
										case '/Nations/NationsIndex.html':routeHandler.display_NationsIndex(pathname, request, response);
                                                                break;
										
										case '/People/addPerson':routeHandler.add_Person(pathname, request, response);
                                                                break;	
										case '/People/editPerson':routeHandler.update_Person(pathname, request, response);
                                                                break;
										case '/People/PeopleEdit.html':routeHandler.display_PeopleEdit(pathname, request, response);
                                                                break;	
										case '/People/PeopleNew.html': routeHandler.display_PersonNew(pathname, request, response);
                                                                break;						
										case '/People/PeopleTemplate.html': routeHandler.display_PeopleTemplate(pathname, request, response);
                                                                break;																									
										case '/People/PeopleIndex.html':routeHandler.display_PeopleIndex(pathname, request, response);
																break;

										
										case '/POI/addPOI':routeHandler.add_POI(pathname, request, response);
                                                                break;	
										case '/POI/editPOI':routeHandler.update_POI(pathname, request, response);
                                                                break;
										case '/POI/POIEdit.html':routeHandler.display_POIEdit(pathname, request, response);
                                                                break;	
										case '/POI/POINew.html': routeHandler.display_POINew(pathname, request, response);
                                                                break;						
										case '/POI/POITemplate.html': routeHandler.display_POITemplate(pathname, request, response);
                                                                break;																									
										case '/POI/POIIndex.html':routeHandler.display_POIIndex(pathname, request, response);
																break;
										
										case '/Towns/addTown':routeHandler.add_Town(pathname, request, response);
                                                                break;	
										case '/Towns/editTown':routeHandler.update_Town(pathname, request, response);
                                                                break;
										case '/Towns/TownsEdit.html':routeHandler.display_TownsEdit(pathname, request, response);
                                                                break;	
										case '/Towns/TownsNew.html': routeHandler.display_TownNew(pathname, request, response);
                                                                break;						
										case '/Towns/TownsTemplate.html': routeHandler.display_TownsTemplate(pathname, request, response);
                                                                break;																									
										case '/Towns/TownsIndex.html':routeHandler.display_TownsIndex(pathname, request, response);
																break;
										

                                       default: routeHandler.display_index_SplashPage(pathname, request,response);
                                       }   
                            }