var url=require('url');
var querystring=require('querystring');
var fs = require('fs');
var WriteJSON = require('./WriteJSON')
var querystring = require("querystring");

exports.display_SplashPage=function(url, request, response){
	response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('./Views/index.html', function (err, html) {
		if (err) {
			throw err; 
		};
		response.write(html);
		response.end();
	});
}


exports.display_index_SplashPage=function(url, request, response){
	response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../Views/index.html', function (err, html) {
		if (err) {
			throw err; 
		};
		response.write(html);
		response.end();
	});
}



exports.get_Data=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../data.json', function (err, data) {
		if (err) {
			throw err;
		};
		response.write(data);
		response.end();
	});
}
	
exports.get_Header=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../header.js', function (err, header) {
		if (err) {
			throw err;
		};
		
		response.write(header);
		response.end();
	});
}

exports.get_Functions=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../functions.js', function (err, header) {
		if (err) {
			throw err;
		};
		
		response.write(header);
		response.end();
	});
}



exports.update_Culture=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../Culture/CultureIndex.html', function (err, html) {
		if (err) {
			throw err;
		};
	name = qs['name'];
	id = qs['id'];
	desc = qs['desc'];
	WriteJSON.updateCulture(id,name,desc)
	response.write(html);
	response.end();
	});
}

exports.add_Culture=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../Culture/CultureIndex.html', function (err, html) {
		if (err) {
			throw err;
		};
	name = qs['name'];
	desc = qs['desc'];
	WriteJSON.addCulture(name,desc);
	response.write(html);
	response.end();
	});
}

exports.display_CultureEdit=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../Culture/CultureEdit.html', function (err, html) {
		if (err) {
			throw err;
		};
		
		response.write(html);
		response.end();
	});
}
	
exports.display_CultureTemplate=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../Culture/CultureTemplate.html', function (err, html) {
		if (err) {
			throw err;
		};
		response.write(html);
		response.end();
	});
}

exports.display_CultureIndex=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../Culture/CultureIndex.html', function (err, html) {
		if (err) {
			throw err;
		};
		response.write(html);
		response.end();
	});
}
	
exports.display_CultureNew=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../Culture/CultureNew.html', function (err, html) {
		if (err) {
			throw err;
		};
	response.write(html);
	response.end();
	});
}



exports.add_God=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../Gods/GodsIndex.html', function (err, html) {
		if (err) {
			throw err;
		};
		
	var culture = qs['culture'];
	var name = qs['name'];
	var alignment = qs['alignment'];
	var domain = qs['domain'];
	var desc = qs['desc'];
	
	
	WriteJSON.addGod(culture,name,desc,alignment,domain);
	response.write(html);
	response.end();
	});
}

exports.update_God=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../Gods/GodsIndex.html', function (err, html) {
		if (err) {
			throw err;
		};
	id = qs['id'];
	name = qs['name'];
	alignment = qs['alignment'];
	domain = qs['domain'];
	desc = qs['desc'];
	WriteJSON.updateGod(id,name,alignment,domain,desc);
	response.write(html);
	response.end();
	});
}

exports.display_GodsEdit=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../Gods/GodsEdit.html', function (err, html) {
		if (err) {
			throw err;
		};
	response.write(html);
	response.end();
	});
}

exports.display_GodsNew=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../Gods/GodsNew.html', function (err, html) {
		if (err) {
			throw err;
		};
	response.write(html);
	response.end();
	});
}

exports.display_GodsTemplate=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../Gods/GodsTemplate.html', function (err, html) {
		if (err) {
			throw err;
		};
		response.write(html);
		response.end();
	});
}

exports.display_GodsIndex=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../Gods/GodsIndex.html', function (err, html) {
		if (err) {
			throw err;
		};
		response.write(html);
		response.end();
	});
}



exports.add_Nation=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../Nations/NationsIndex.html', function (err, html) {
		if (err) {
			throw err;
		};
	name = qs['name'];
	culture = qs['culture'];
	id = qs['id'];
	desc = qs['desc'];
	WriteJSON.addNation(culture,id,name,desc);
	response.write(html);
	response.end();
	});
}

exports.update_Nation=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../Nations/NationsIndex.html', function (err, html) {
		if (err) {
			throw err;
		};
	id = qs['id'];
	name = qs['name'];
	desc = qs['desc'];
	capitalid = qs['capitalid'];
	allies = qs['allies'];
	console.log("Allies:" + allies);	
	enemies = qs['enemies'];
	if ((typeof enemies) == 'undefined'){
		enemies = []
	}
	if ((typeof allies )== 'undefined'){
		allies = []
	}
	WriteJSON.updateNation(id,name,desc,capitalid,allies,enemies);
	response.write(html);
	response.end();
	});
}

exports.display_NationsEdit=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../Nations/NationsEdit.html', function (err, html) {
		if (err) {
			throw err;
		};
		
		response.write(html);
		response.end();
	});
}

exports.display_NationNew=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../Nations/NationsNew.html', function (err, html) {
		if (err) {
			throw err;
		};
		response.write(html);
		response.end();
	});
}

exports.display_NationsTemplate=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../Nations/NationsTemplate.html', function (err, html) {
		if (err) {
			throw err;
		};
		response.write(html);
		response.end();
	});
}

exports.display_NationsIndex=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../Nations/NationsIndex.html', function (err, html) {
		if (err) {
			throw err;
		};
		response.write(html);
		response.end();
	});
}



exports.add_Person=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../People/PeopleIndex.html', function (err, html) {
		if (err) {
			throw err;
		};
	culture = qs['culture'];
	name = qs['name'];
	desc = qs['desc'];
	nation = qs['nation'];
	status_ = qs['status'];
	race = qs['race'];
	job = qs['job'];
	town = qs['town'];
	WriteJSON.addPerson(culture,name,desc,nation,status_,race,job,town);
	response.write(html);
	response.end();
	});
}

exports.update_Person=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../People/PeopleIndex.html', function (err, html) {
		if (err) {
			throw err;
		};
	name = qs['name'];
	status1 = qs['status'];
	desc = qs['desc'];
	id = qs['id'];
	race = qs['race'];
	job = qs['job'];
	locationid = qs['town'];
	associates= []
	var x=0;
	while (qs['peopleform'+x] != null){
		associates.push({
			"id": qs['peopleform'+x],
			"relationship" : qs['relationship'+x]
		})
		x++;
	}
	console.log(associates);
	WriteJSON.updatePerson(name,status1,desc,id,race,job,locationid,associates);
	response.write(html);
	response.end();
	});
}

exports.display_PeopleEdit=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../People/PeopleEdit.html', function (err, html) {
		if (err) {
			throw err;
		};
		
		response.write(html);
		response.end();
	});
}

exports.display_PersonNew=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../People/PeopleNew.html', function (err, html) {
		if (err) {
			throw err;
		};
		response.write(html);
		response.end();
	});
}

exports.display_PeopleTemplate=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../People/PeopleTemplate.html', function (err, html) {
		if (err) {
			throw err;
		};
		response.write(html);
		response.end();
	});
}

exports.display_PeopleIndex=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../People/PeopleIndex.html', function (err, html) {
		if (err) {
			throw err;
		};
		response.write(html);
		response.end();
	});
}


exports.add_POI=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../POI/POIIndex.html', function (err, html) {
		if (err) {
			throw err;
		};
	name = qs['name'];
	culture = qs['culture'];
	desc = qs['desc'];
	nation = qs['nation'];
	town = qs['town'];
	WriteJSON.addPOI(culture,nation,town, name, desc);
	response.write(html);
	response.end();
	});
}

exports.update_POI=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../POI/POIIndex.html', function (err, html) {
		if (err) {
			throw err;
		};
	id = qs['id'];
	name = qs['name'];
	desc = qs['desc'];
	WriteJSON.updatePOI(id,name,desc);
	response.write(html);
	response.end();
	});
}

exports.display_POIEdit=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../POI/POIEdit.html', function (err, html) {
		if (err) {
			throw err;
		};
		
		response.write(html);
		response.end();
	});
}

exports.display_POINew=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../POI/POINew.html', function (err, html) {
		if (err) {
			throw err;
		};
		response.write(html);
		response.end();
	});
}

exports.display_POITemplate=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../POI/POITemplate.html', function (err, html) {
		if (err) {
			throw err;
		};
		response.write(html);
		response.end();
	});
}

exports.display_POIIndex=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../POI/POIIndex.html', function (err, html) {
		if (err) {
			throw err;
		};
		response.write(html);
		response.end();
	});
}



exports.add_Town=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../Towns/TownsIndex.html', function (err, html) {
		if (err) {
			throw err;
		};
	name = qs['name'];
	culture = qs['culture'];
	desc = qs['desc'];
	nation = qs['nation'];
	pop = qs['pop'];
	cat = qs['cat'];
	WriteJSON.addTown(culture,name,desc,nation,pop,cat);
	response.write(html);
	response.end();
	});
}

exports.update_Town=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../Towns/TownsIndex.html', function (err, html) {
		if (err) {
			throw err;
		};
	id = qs['id'];
	name = qs['name'];
	desc = qs['desc'];
	pop = qs['pop'];
	category = qs['category'];
	importantpeople= []
	var x=0;
	while (qs['peopleform'+x] != null){
		importantpeople.push({
			"id": qs['peopleform'+x],
			"desc" : qs['role'+x]
		})
		x++;
	}
	
	WriteJSON.updateTown(id,name,desc,pop, category,importantpeople);
	response.write(html);
	response.end();
	});
}

exports.display_TownsEdit=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../Towns/TownsEdit.html', function (err, html) {
		if (err) {
			throw err;
		};
		
		response.write(html);
		response.end();
	});
}

exports.display_TownNew=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../Towns/TownsNew.html', function (err, html) {
		if (err) {
			throw err;
		};
		response.write(html);
		response.end();
	});
}

exports.display_TownsTemplate=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../Towns/TownsTemplate.html', function (err, html) {
		if (err) {
			throw err;
		};
		response.write(html);
		response.end();
	});
}

exports.display_TownsIndex=function(url, request, response){
    response.writeHead(200,{'Content-Type': 'text/html'});
	fs.readFile('../Towns/TownsIndex.html', function (err, html) {
		if (err) {
			throw err;
		};
		response.write(html);
		response.end();
	});
}
